package task2;

import common.BaseThread;

/**
 * Class Philosopher.
 * Outlines main subrutines of our virtual philosopher.
 *
 * @author Serguei A. Mokhov, mokhov@cs.concordia.ca
 */
public class Philosopher extends BaseThread
{
	/**
	 * Max time an action can take (in milliseconds)
	 */
	public static final long TIME_TO_WASTE = 1000;

	/**
	 * The act of eating.
	 * - Print the fact that a given phil (their TID) has started eating.
	 * - yield
	 * - Then sleep() for a random interval.
	 * - yield
	 * - The print that they are done eating.
	 */
	public void eat()
	{
		try
		{
			System.out.println("Philosopher No. " +this.iTID+ " has started eating."); // TASK 1 : Print fact
			yield(); //TASK 1 : Yield
			sleep((long)(Math.random() * TIME_TO_WASTE));  // TASK 1 : Sleep for random interval
			yield(); //TASK 1 : Yield
			System.out.println("Philosopher No. " +this.iTID+ " has finished eating."); // TASK 1 : Print fact
		}
		catch(InterruptedException e)
		{
			System.err.println("Philosopher.eat():");
			DiningPhilosophers.reportException(e);
			System.exit(1);
		}
	}

	/**
	 * The act of thinking.
	 * - Print the fact that a given phil (their TID) has started thinking.
	 * - yield
	 * - Then sleep() for a random interval.
	 * - yield
	 * - The print that they are done thinking.
	 */
	public void think()
	{
		try
		{
			System.out.println("() Philosopher No. " +this.iTID+ " has started thinking. ()"); // TASK 1 : Print fact
			yield(); //TASK 1 : Yield
			sleep((long)(Math.random() * TIME_TO_WASTE));  // TASK 1 : Sleep for random interval
			yield(); //TASK 1 : Yield
			System.out.println("() Philosopher No. " +this.iTID+ " has finished thinking. ()"); // TASK 1 : Print fact
		}
		catch(InterruptedException e)
		{
			System.err.println("Philosopher.think():");
			DiningPhilosophers.reportException(e);
			System.exit(1);
		}
	}

	/**
	 * The act of talking.
	 * - Print the fact that a given phil (their TID) has started talking.
	 * - yield
	 * - Say something brilliant at random
	 * - yield
	 * - The print that they are done talking.
	 */
	public void talk()
	{	
		System.out.println(">> Philosopher No. " +this.iTID+ " has started talking."); // TASK 1 : Print fact
		yield(); //TASK 1 : Yield
		saySomething(); // TASK 1 : Say something brilliant at random
		try {
			sleep((long)(Math.random() * TIME_TO_WASTE));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  // TASK 2 : Sleep for random interval
		yield(); //TASK 1 : Yield
		System.out.println(">> Philosopher No. " +this.iTID+ " has finished talking."); // TASK 1 : Print fact
	}

	/**
	 * No, this is not the act of running, just the overridden Thread.run()
	 */
	public void run()
	{
		for(int i = 0; i < DiningPhilosophers.DINING_STEPS; i++)
		{
			DiningPhilosophers.soMonitor.pickUp(getTID());

			eat();

			DiningPhilosophers.soMonitor.putDown(getTID());

			think();

			/*
			 * TODO:
			 * A decision is made at random whether this particular
			 * philosopher is about to say something terribly useful.
			 */
			if(Math.random() < .85) // TASK 1  : let there be a frequent interval
			{
				DiningPhilosophers.soMonitor.requestTalk(); // TASK 2
				talk();
				DiningPhilosophers.soMonitor.endTalk(); // TASK 2
			}

			yield();
		}
	} // run()

	/**
	 * Prints out a phrase from the array of phrases at random.
	 * Feel free to add your own phrases.
	 */
	public void saySomething()
	{
		String[] astrPhrases =
		{
			"\"... Why did we only bring one sole chopstick to this gathering? Damn it Richard!\"",
			"\"Might we instead break each chopstick into two halves of a whole?\"",
			"\"Eating with chopsticks is the result of a social contruct. Pass me a fork!\"",
			"\"Finite chopsticks... yet! INFINITE noodles! Reality is strange.\"",
			"\"\n\n    |        | |      \n\n    | |      |__\n"
		};

		System.out.println
		(
			"Philosopher " + getTID() + " says: " +
			astrPhrases[(int)(Math.random() * astrPhrases.length)]
		);
	}
}

// EOF
