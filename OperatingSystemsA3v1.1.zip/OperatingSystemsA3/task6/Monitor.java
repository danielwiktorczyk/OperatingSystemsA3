package task6;
/**
 * Class Monitor
 * To synchronize dining philosophers.
 *
 * @author Serguei A. Mokhov, mokhov@cs.concordia.ca
 */
public class Monitor
{
	/*
	 * ------------
	 * Data members
	 * ------------
	 */
	private int numberOfChopsticks;
	private boolean[] chopsticksInUse;
	private boolean currentSpeaker;
	private int availablePepperShakers;

	/**
	 * Constructor
	 */
	public Monitor(int piNumberOfPhilosophers)
	{
		// TODO: set appropriate number of chopsticks based on the # of philosophers
		setNumberOfChopsticks(piNumberOfPhilosophers); // TASK 2	
		setChopsticksInUse(); // TASK 2
		currentSpeaker = false; // TASK 2
		availablePepperShakers = 2;
	}

	private void setChopsticksInUse() {
		this.chopsticksInUse = new boolean[numberOfChopsticks];
	}

	private void setNumberOfChopsticks(int piNumberOfPhilosophers) {
		if (piNumberOfPhilosophers < 2)
			this.numberOfChopsticks = 2;
		else 
			this.numberOfChopsticks = piNumberOfPhilosophers;
	}

	/*
	 * -------------------------------
	 * User-defined monitor procedures
	 * -------------------------------
	 */

	/**
	 * Grants request (returns) to eat when both chop sticks/forks are available.
	 * Else forces the philosopher to wait()
	 */
	public synchronized void pickUp(final int piTID)
	{
		boolean isInEvenSeat = piTID % 2 == 0; // TASK 2 : Determine seat priority
		
		pickupPrimaryStick(isInEvenSeat, piTID);
		
		pickupSecondaryStick(isInEvenSeat, piTID);
		
		this.chopsticksInUse[leftChopstick(piTID)] = true;
		this.chopsticksInUse[rightChopstick(piTID)] = true;
	}

	private void pickupSecondaryStick(boolean isInEvenSeat, int piTID) {
		if (!isInEvenSeat) {
			while (this.chopsticksInUse[leftChopstick(piTID)])
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		} else {
			while (this.chopsticksInUse[rightChopstick(piTID)])
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	private void pickupPrimaryStick(boolean isInEvenSeat, int piTID) {
		if (isInEvenSeat) {
			while (this.chopsticksInUse[leftChopstick(piTID)])
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		} else {
			while (this.chopsticksInUse[rightChopstick(piTID)])
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	private int leftChopstick(int piTID) {
		return (piTID + numberOfChopsticks - 1) % numberOfChopsticks;
	}
	
	private int rightChopstick(int piTID) {
		return (piTID + numberOfChopsticks - 2) % numberOfChopsticks;
	}

	/**
	 * When a given philosopher's done eating, they put the chop sticks/forks down
	 * and let others know they are available.
	 */
	public synchronized void putDown(final int piTID)
	{
		// ...
		this.chopsticksInUse[leftChopstick(piTID)] = false;
		this.chopsticksInUse[rightChopstick(piTID)] = false;
		notifyAll(); // TASK 2
	}

	/**
	 * Only one philopher at a time is allowed to philosophy
	 * (while she is not eating).
	 */
	public synchronized void requestTalk()
	{
		while (currentSpeaker) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		currentSpeaker = true;
	}

	/**
	 * When one philosopher is done talking stuff, others
	 * can feel free to start talking.
	 */
	public synchronized void endTalk()
	{
		currentSpeaker = false;
		notifyAll();
	}

	public synchronized void pickUpPepper() {
		
		while (availablePepperShakers == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		availablePepperShakers--;
		
	}

	public synchronized void putDownPepper() {
		availablePepperShakers++;
		notifyAll();
	}
}

// EOF
